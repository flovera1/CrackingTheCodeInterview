'''
FIFO
'''
class Node:
	def __init__(self, valData = None, valNext = None, valPrev = None)
		self.data = valData
		self.next = valNext
		self.prev = valPrev

class Queue:
	def __init__