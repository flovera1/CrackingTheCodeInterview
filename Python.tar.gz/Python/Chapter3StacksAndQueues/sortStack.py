'''
Write a program to sort a stack such that the smallest items are on the top.
You can use an additional temporary stack, but you may not copy the elements into any
other data structure (sucha as an array). The stack supports the following operations: push, pop, peed
and isEmpty.
'''
